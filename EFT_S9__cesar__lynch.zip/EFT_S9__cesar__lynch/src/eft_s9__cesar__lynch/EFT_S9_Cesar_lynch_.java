/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eft_s9__cesar__lynch;

/**
 *
 * @author sd
 */  import java.util.*;


import java.util.*;

class Entrada {
    private static int contadorIds = 1;
    private int id;
    private String tipo;
    private double precio;

    public Entrada(String tipo, double precio) {
        this.id = contadorIds++;
        this.tipo = tipo;
        this.precio = precio;
    }

    public int getId() {
        return id;
    }

    public String getTipo() {
        return tipo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
}

class SistemaEntradas {
    private List<Entrada> entradasCompradas;

    public SistemaEntradas() {
        this.entradasCompradas = new ArrayList<>();
    }

    public void venderEntrada(String tipo, int cantidad, boolean esEstudiante, boolean esTerceraEdad) {
        double precio;
        switch (tipo) {
            case "Concierto":
                precio = esEstudiante ? 6000 : 7500;
                break;
            case "Museo":
                precio = esEstudiante ? 2000 : 3500;
                break;
            case "Charla Motivacional":
                precio = esEstudiante ? 1000 : 2000;
                break;
            default:
                System.out.println("Tipo de entrada no válido");
                return;
        }
        if (esTerceraEdad) {
            precio *= 0.7; // 30% de descuento para personas de tercera edad
        } else if (esEstudiante) {
            precio *= 0.85; // 15% de descuento para estudiantes
        }
        for (int i = 0; i < cantidad; i++) {
            entradasCompradas.add(new Entrada(tipo, precio));
        }
        System.out.println("Entradas vendidas exitosamente");
    }

    public void verEntradasCompradas() {
        System.out.println("Entradas compradas:");
        for (Entrada entrada : entradasCompradas) {
            System.out.println("ID: " + entrada.getId() + ", Tipo: " + entrada.getTipo() + ", Precio: " + entrada.getPrecio());
        }
    }

    public void actualizarEntrada(int id, double nuevoPrecio) {
        for (Entrada entrada : entradasCompradas) {
            if (entrada.getId() == id) {
                entrada.setPrecio(nuevoPrecio);
                System.out.println("Entrada actualizada exitosamente");
                return;
            }
        }
        System.out.println("ID de entrada no encontrado");
    }

    public void borrarEntrada(int id) {
        Iterator<Entrada> iterator = entradasCompradas.iterator();
        while (iterator.hasNext()) {
            Entrada entrada = iterator.next();
            if (entrada.getId() == id) {
                iterator.remove();
                System.out.println("Entrada eliminada exitosamente");
                return;
            }
        }
        System.out.println("ID de entrada no encontrado");
    }
}

public class EFT_S9_Cesar_lynch_  {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SistemaEntradas sistema = new SistemaEntradas();

        int opcion;
        do {
            System.out.println("\nMenu:");
            System.out.println("1. Venta de entradas");
            System.out.println("2. Ver entradas compradas");
            System.out.println("3. Actualizar entrada");
            System.out.println("4. Borrar entrada");
            System.out.println("5. Salir");
            System.out.print("Ingrese opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("\nTipos de entrada:");
                    System.out.println("1. Concierto");
                    System.out.println("2. Museo");
                    System.out.println("3. Charla Motivacional");
                    System.out.print("Seleccione el tipo de entrada: ");
                    int tipoEntrada = scanner.nextInt();
                    System.out.print("Ingrese cantidad de entradas: ");
                    int cantidad = scanner.nextInt();
                    System.out.print("¿Es estudiante? (true/false): ");
                    boolean esEstudiante = scanner.nextBoolean();
                    System.out.print("¿Es persona de tercera edad? (true/false): ");
                    boolean esTerceraEdad = scanner.nextBoolean();
                    switch (tipoEntrada) {
                        case 1:
                            sistema.venderEntrada("Concierto", cantidad, esEstudiante, esTerceraEdad);
                            break;
                        case 2:
                            sistema.venderEntrada("Museo", cantidad, esEstudiante, esTerceraEdad);
                            break;
                        case 3:
                            sistema.venderEntrada("Charla Motivacional", cantidad, esEstudiante, esTerceraEdad);
                            break;
                        default:
                            System.out.println("Opción no válida");
                    }
                    break;
                case 2:
                    sistema.verEntradasCompradas();
                    break;
                case 3:
                    System.out.print("Ingrese ID de la entrada a actualizar: ");
                    int idActualizar = scanner.nextInt();
                    System.out.print("Ingrese nuevo precio: ");
                    double nuevoPrecio = scanner.nextDouble();
                    sistema.actualizarEntrada(idActualizar, nuevoPrecio);
                    break;
                case 4:
                    System.out.print("Ingrese ID de la entrada a borrar: ");
                    int idBorrar = scanner.nextInt();
                    sistema.borrarEntrada(idBorrar);
                    break;
                case 5:
                    System.out.println("Muchas gracias por venir al Centro Moro.");
                    break;
                default:
                    System.out.println("Opción no válida");
            }
        } while (opcion != 5);
        scanner.close();
    }
}
